Note:

	We broke our interpreter into several files so it would be easier
	to read our code.

Running Instructions:

	Main method can be found in the file interpreter4.scm

File Descriptions:

	carcdrHelpers.scm
		- Contains basic renaming (defining) of operations on a 		list

	classParser.scm
		-parses simple Java statements (Provided with assignment)

	errorHelpers.scm
		-defines functions that help check for errors

	interpreter4.scm
		-main interpreter program

	lex.scm
		-a lexical analyzer (provided with assignment)
	
	stateHelpers.scm
		-storing of the enviroment and state functions